.class public final synthetic Lcom/nidyaber/fuckdsmanger/gm/GmUi$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/view/View$OnClickListener;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View$OnClickListener;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/nidyaber/fuckdsmanger/gm/GmUi$0;->f$0:Landroid/view/View$OnClickListener;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 2

    .line 0
    iget-object p0, p0, Lcom/nidyaber/fuckdsmanger/gm/GmUi$0;->f$0:Landroid/view/View$OnClickListener;

    invoke-static {p0, p1}, Lcom/nidyaber/fuckdsmanger/gm/GmUi;->lambda$navBar$0(Landroid/view/View$OnClickListener;Landroid/view/View;)V

    return-void
.end method
