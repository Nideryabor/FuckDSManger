.class public final synthetic Lcom/nidyaber/fuckdsmanger/gm/GmHomeUi$1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/nidyaber/fuckdsmanger/gm/GmHomeUi$1;->f$0:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 2

    .line 0
    iget p0, p0, Lcom/nidyaber/fuckdsmanger/gm/GmHomeUi$1;->f$0:I

    invoke-static {p0, p1}, Lcom/nidyaber/fuckdsmanger/gm/GmHomeUi;->lambda$openInner$1(ILandroid/view/View;)V

    return-void
.end method
