#!/usr/bin/env python3
# 整行底扫描：找"横贯整行、颜色近似均匀"的横条，报几何+颜色
import sys
from PIL import Image
def scan(p, minw=0.75, minh=8, tol=10):
    im = Image.open(p).convert('RGB'); w,h = im.size; px = im.load()
    step = max(1, w//200)
    rows=[]
    for y in range(0,h):
        # 采样该行
        cols = list(range(0,w,step))
        vals=[px[x,y] for x in cols]
        # 取众数近似：与中位色差 <= tol 的比例
        med = sorted(vals, key=lambda c: sum(c))[len(vals)//2]
        ok = sum(1 for c in vals if abs(c[0]-med[0])<=tol and abs(c[1]-med[1])<=tol and abs(c[2]-med[2])<=tol)
        rows.append((y, med, ok/len(vals)))
    # 聚合成连续块
    out=[]; cur=None
    for y,med,ratio in rows:
        if ratio>=minw:
            if cur is None: cur=[y,y,med,1]
            else:
                cur[1]=y; cur[3]+=1
                cur[2]=tuple((cur[2][i]*0.7+med[i]*0.3) for i in range(3))
        else:
            if cur and (cur[1]-cur[0]+1)>=minh: out.append(cur)
            cur=None
    if cur and (cur[1]-cur[0]+1)>=minh: out.append(cur)
    print(f"== {p} {w}x{h}")
    for y0,y1,med,n in out:
        print(f"   行 {y0}-{y1} (高{y1-y0+1})  色 #{int(med[0]):02X}{int(med[1]):02X}{int(med[2]):02X}")
for p in sys.argv[1:]: scan(p)
