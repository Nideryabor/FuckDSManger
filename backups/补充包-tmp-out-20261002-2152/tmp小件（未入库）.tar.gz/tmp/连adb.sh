#!/bin/sh
# ============================================================================
#  连adb.sh —— 从容器里钻进 adbd，借 shell 的身体爬出牢笼 🐲
#
#  用法：
#    sh 连adb.sh <配对端口> <配对码> [连接端口]
#      例：sh 连adb.sh 41234 123456 37000
#      或：sh 连adb.sh 41234 123456            （连接端口自动扫）
#
#  全程：起 server → 配对 → 连接 → 验身份 → 试 su
# ============================================================================
export HOME=/root
PAIR_PORT="$1"; CODE="$2"; CONN_PORT="$3"

say() { printf '\n\033[36m══ %s\033[0m\n' "$*"; }
run() { timeout 30 "$@" 2>&1; }

say "0. adb 在不在"
run adb version | head -1

say "1. mdns 自动发现（能白捡端口）"
run adb mdns check
run adb mdns services

say "2. 自动扫连接端口（本地 30000-50000 找 adb banner）"
if [ -z "$CONN_PORT" ]; then
python3 - <<'PY' 2>&1
import socket, concurrent.futures
def probe(p):
    try:
        s = socket.create_connection(('127.0.0.1', p), timeout=0.25)
        s.settimeout(0.4)
        try:
            b = s.recv(24)
            if b.startswith(b'CNXN') or b.startswith(b'AUTH') or b'android' in b.lower():
                return (p, b[:20])
        finally:
            s.close()
    except Exception:
        pass
    return None
found=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=400) as ex:
    for r in ex.map(probe, range(30000, 50001)):
        if r: found.append(r)
for p, b in sorted(found):
    print(f'   ↳ 找到 adb 端口: 127.0.0.1:{p}  (banner={b!r})')
if not found:
    print('   （没扫到 —— 可能无线调试还没开，或只绑在 wlan 网卡上）')
PY
fi

say "3. 配对"
if [ -n "$PAIR_PORT" ] && [ -n "$CODE" ]; then
  run adb pair "127.0.0.1:$PAIR_PORT" "$CODE"
else
  printf '   （没给配对端口/配对码，跳过）\n'
fi

say "4. 连接"
P="${CONN_PORT:-5555}"
run adb connect "127.0.0.1:$P"
run adb devices -l

say "5. 验身份（关键：应该是 uid 2000 shell，不是 10370）"
run adb shell id
run adb shell 'cat /proc/self/attr/current' 2>/dev/null

say "6. 试 su（这才是终点）"
run adb shell su -c 'id'
run adb shell su -c 'echo SU_OK; ls /data/data | head -5'

say "7. 要是上面成了，这些就都能用了"
run adb shell su -c 'logcat -d -t 3 | head -3'
