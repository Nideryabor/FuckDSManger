from PIL import Image
import sys, statistics

CH = " .:-=+*#%@"   # 暗 -> 亮

def analyze(path, gw=64, gh=28):
    im = Image.open(path).convert('RGB')
    w, h = im.size
    print("="*70)
    print(f"FILE: {path}")
    print(f"SIZE: {w}x{h}   aspect={w/h:.3f}")
    # 亮度 ASCII 图
    small = im.resize((gw, gh), Image.LANCZOS)
    px = small.load()
    print("--- luminance map (dark=' ' .. bright='@') ---")
    for y in range(gh):
        row = ""
        for x in range(gw):
            r, g, b = px[x, y]
            lum = 0.299*r + 0.587*g + 0.114*b
            i = int(lum / 256.0 * len(CH)); i = min(i, len(CH)-1)
            row += CH[i]
        print(row)
    # 全局统计
    st = im.resize((160, 160), Image.LANCZOS).load()
    lums = []
    for y in range(160):
        for x in range(160):
            r, g, b = st[x, y]
            lums.append(0.299*r + 0.587*g + 0.114*b)
    print(f"LUM: mean={statistics.mean(lums):.1f}  sd={statistics.pstdev(lums):.1f}  min={min(lums):.0f}  max={max(lums):.0f}")
    # 上中下三段平均亮度（看纵向层次）
    seg = 160 // 3
    for name, y0, y1 in (("TOP", 0, seg), ("MID", seg, 2*seg), ("BOT", 2*seg, 160)):
        vals = []
        for y in range(y0, y1):
            for x in range(160):
                r, g, b = st[x, y]
                vals.append(0.299*r + 0.587*g + 0.114*b)
        print(f"  {name}: mean={statistics.mean(vals):.1f}  sd={statistics.pstdev(vals):.1f}")
    # 主色 top8
    q = im.resize((120, 120), Image.LANCZOS).quantize(colors=8, method=Image.MEDIANCUT).convert('RGB')
    cnt = {}
    qp = q.load()
    for y in range(120):
        for x in range(120):
            cnt[qp[x, y]] = cnt.get(qp[x, y], 0) + 1
    print("--- top colors (quantized) ---")
    for c, n in sorted(cnt.items(), key=lambda kv: -kv[1])[:8]:
        print(f"  #{c[0]:02X}{c[1]:02X}{c[2]:02X}  {100.0*n/14400:.1f}%")

for p in sys.argv[1:]:
    analyze(p)
