from PIL import Image
import sys, statistics

CH = " .:-=+*#%@"

def hx(c): return "#%02X%02X%02X" % c

def analyze(path, gw=64, gh=30):
    im = Image.open(path).convert('RGB')
    w, h = im.size
    print("="*72)
    print(f"FILE: {path}")
    print(f"SIZE: {w}x{h}")
    small = im.resize((gw, gh), Image.LANCZOS)
    px = small.load()
    print("--- luminance map (dark=' ' .. bright='@') ---")
    for y in range(gh):
        print("".join(CH[min(int((0.299*px[x,y][0]+0.587*px[x,y][1]+0.114*px[x,y][2])/256*10),9)] for x in range(gw)))
    # 量化主色 + 位置分布
    q = im.resize((180, 396), Image.LANCZOS).quantize(colors=10, method=Image.MEDIANCUT).convert('RGB')
    qp = q.load(); W, H = 180, 396
    buckets = {}
    for y in range(H):
        band = 0 if y < H//3 else (1 if y < 2*H//3 else 2)
        for x in range(W):
            c = qp[x, y]
            b = buckets.setdefault(c, [0,0,0,0])
            b[0] += 1; b[1+band] += 1
    print("--- top colors (% of screen | TOP/MID/BOT share) ---")
    for c, b in sorted(buckets.items(), key=lambda kv: -kv[1][0])[:10]:
        tot = b[0]; pct = 100.0*tot/(W*H)
        t, m, bo = [100.0*x/tot for x in b[1:4]]
        lum = 0.299*c[0]+0.587*c[1]+0.114*c[2]
        print(f"  {hx(c)}  lum={lum:6.1f}  {pct:5.1f}%   TOP {t:4.0f}% | MID {m:4.0f}% | BOT {bo:4.0f}%")
    st = im.resize((160,160), Image.LANCZOS).load()
    lums = [0.299*st[x,y][0]+0.587*st[x,y][1]+0.114*st[x,y][2] for y in range(160) for x in range(160)]
    print(f"GLOBAL: mean={statistics.mean(lums):.1f} sd={statistics.pstdev(lums):.1f}")

for p in sys.argv[1:]:
    analyze(p)
