#!/usr/bin/env python3
"""把 m3e 静态站挂到 8080（双 fork 脱离会话，尽量不被回收）"""
import os, sys, http.server, socketserver, functools

ROOT = "/workspace/tmp/m3e-out"
PORT = 8080

if len(sys.argv) > 1 and sys.argv[1] == "--daemon":
    if os.fork() > 0: os._exit(0)
    os.setsid()
    if os.fork() > 0: os._exit(0)
    sys.stdout = sys.stderr = open("/tmp/serve.log", "a")
    os.chdir(ROOT)

H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("0.0.0.0", PORT), H) as httpd:
    httpd.serve_forever()
