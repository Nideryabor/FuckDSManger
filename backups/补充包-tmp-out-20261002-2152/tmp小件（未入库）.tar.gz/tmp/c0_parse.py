# -*- coding: utf-8 -*-
"""C0：从宿主 Lo02.<init> 里抽出「权威设置表」🐲"""
import re, sys, collections

p = 'tmp/host252/sm/o02.smali'
src = open(p, encoding='utf-8').read().split('\n')

# 取 <init> 方法体
i0 = next(i for i, l in enumerate(src) if l.startswith('.method public constructor <init>()V'))
i1 = next(i for i in range(i0, len(src)) if src[i].strip() == '.end method')
body = [l.strip() for l in src[i0:i1] if l.strip() and not l.strip().startswith('.line')
        and not l.strip().startswith('.registers') and not l.strip().startswith('.param')
        and not l.strip().startswith('#')]

reg = {}
entries = []
pending = None          # 待绑定的 const-string（准备喂给 valueOf/构造）

def val(r):
    r = r.strip().lstrip("v")
    v = reg.get(r)
    if v is None: return '?'
    kind, x = v
    if kind in ('str', 'int', 'long', 'obj'): return str(x)
    return '?'

last_entry = None
for k, ins in enumerate(body):
    m = re.match(r'const-string v(\d+), "(.*)"$', ins)
    if m:
        reg[m.group(1)] = ('str', m.group(2)); pending = m.group(1); continue
    m = re.match(r'const(?:/4|/16|/high16)? v(\d+), (0x[0-9a-fA-F-]+|-?\d+)$', ins)
    if m:
        reg[m.group(1)] = ('int', int(m.group(2), 0)); pending = m.group(1); continue
    m = re.match(r'const-wide(?:/16|/32|/high16)? v(\d+), (0x[0-9a-fA-F-]+|-?\d+)$', ins)
    if m:
        reg[m.group(1)] = ('long', int(m.group(2), 0)); pending = m.group(1); continue
    m = re.match(r'sget-object v(\d+), (L[^;]+;->[^:]+:[^\s]+)$', ins)
    if m:
        reg[m.group(1)] = ('obj', m.group(2)); pending = None; continue
    m = re.match(r'new-instance v(\d+), (L[^;]+;)$', ins)
    if m:
        reg[m.group(1)] = ('new', m.group(2)); pending = None; continue
    if 'String;->valueOf(I)' in ins or 'String;->valueOf(J)' in ins:
        continue
    m = re.match(r'move-result-object v(\d+)$', ins)
    if m:
        # 结果来自上一条 invoke：valueOf(int) → 字符串化的数字；否则未知
        prev = body[k-1] if k else ''
        if 'String;->valueOf' in prev and pending:
            reg[m.group(1)] = ('str', val(pending))
        else:
            reg[m.group(1)] = ('obj', '<call>')
        pending = None; continue
    m = re.match(r'move-result(?:-wide)? v(\d+)$', ins)
    if m:
        reg[m.group(1)] = ('int', '<call>'); continue
    # ★ 关键：Ln02 构造
    m = re.match(r'invoke-direct \{([^}]+)\}, Ln02;-><init>\(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;\)V$', ins)
    if m:
        rs = [x.strip() for x in m.group(1).split(',')]
        if len(rs) == 5:
            last_entry = {'key': val(rs[1]), 'comment': val(rs[2]), 'type': val(rs[3]),
                          'default': val(rs[4]), 'probe': '?'}
            entries.append(last_entry)
        continue
    # MMKV->contains(X) → 记录宿主探测的键形
    m = re.match(r'invoke-virtual \{v(\d+), (v\d+)\}, Lcom/tencent/mmkv/MMKV;->contains\(Ljava/lang/String;\)Z$', ins)
    if m and last_entry is not None:
        last_entry['probe'] = val(m.group(2))
        continue
    # 其它 invoke：作废 move-result 的假设
    if ins.startswith('invoke-'):
        pending = None

print("抽出 %d 项 / 期望 63 项" % len(entries))
kinds = collections.Counter(e['type'] for e in entries)
print("类型分布:", dict(kinds))
probes = collections.Counter(e['probe'] for e in entries)
print("探测键形:", dict(probes))
bad = [e for e in entries if '?' in (e['key'], e['type']) or e['default'] == '?']
print("有未解析字段的项: %d" % len(bad))
for e in bad[:8]: print("   ", e)

# 落盘
with open('参考/数据/host-2.5.2-设置表.tsv', 'w', encoding='utf-8') as f:
    f.write("# 宿主 DeepSeek 2.5.2 (com.deepseek.chat.a / vc273) 权威设置表 🐲\n")
    f.write("# 来源：Lo02.<init>（baksmali 自 classes.dex）—— C0 产出\n")
    f.write("# 列：纯名\t类型\t默认值\t宿主实际探测的键\t注释\n")
    for e in entries:
        f.write("%s\t%s\t%s\t%s\t%s\n" % (e['key'], e['type'], e['default'], e['probe'], e['comment']))
print("\n→ 参考/数据/host-2.5.2-设置表.tsv")
