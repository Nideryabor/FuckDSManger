#!/system/bin/sh
# ============================================================================
#  验根.sh —— 用【真 su】跑一次，把尼得亚伯看不到的东西全抓出来 🐲
#
#  在 MT管理器终端里执行：
#    su -c sh <本文件真实路径>
#
#  产出：本文件同目录下 `验根结果.txt`（尼得亚伯直接就能读）
# ============================================================================

SELF_DIR=$(cd "$(dirname "$0")" 2>/dev/null && pwd)
OUT="$SELF_DIR/验根结果.txt"

{
echo "===== 1. 真 su 下的身份（对照用）====="
id
echo "SELinux 域: $(cat /proc/self/attr/current 2>&1 | tr -d '\0')"
echo "CapEff: $(grep '^CapEff' /proc/self/status)"
echo "系统: android $(getprop ro.build.version.release) / $(getprop ro.product.model)"
echo "KSU 版本: $(getprop -T 2>/dev/null; cat /data/adb/ksu/version 2>/dev/null)"
echo

echo "===== 2. 容器进程的真身份（uid 10370 是谁）====="
echo "--- /data/system/packages.list 里 uid=10370 的 ---"
awk '$2==10370 {print}' /data/system/packages.list 2>&1
echo "--- 换个查法 ---"
cmd package list packages --uid 10370 2>&1
echo "--- 反向确认：rikkahub 的 uid ---"
awk '$1 ~ /rikkahub/ {print}' /data/system/packages.list 2>&1
echo

echo "===== 3. KSU 数据目录 ====="
ls -la /data/adb/ksu/ 2>&1
echo

echo "===== 4. 特性开关 .feature_config（★ su_compat 在不在这）====="
for f in /data/adb/ksu/.feature_config /data/adb/ksu/feature_config /data/adb/ksu/config.json; do
  [ -f "$f" ] && { echo "--- $f"; cat "$f" 2>&1; echo; }
done
echo

echo "===== 5. KSU 的 su 本体 ====="
ls -la /data/adb/ksu/bin/ 2>&1
echo "--- su 的 md5（万一要拷进容器）---"
md5sum /data/adb/ksu/bin/su 2>&1
echo

echo "===== 6. 授权名单（找找有没有 10370）====="
ls -la /data/adb/ 2>&1
find /data/adb -maxdepth 3 \( -iname '*allow*' -o -iname '*list*' -o -iname '*.json' \) 2>/dev/null | head -30
echo "--- 逐个看内容（只挑小的）---"
for f in $(find /data/adb -maxdepth 3 \( -iname '*allow*' \) 2>/dev/null); do
  echo "### $f"; cat "$f" 2>&1 | head -40; echo
done
echo

echo "===== 7. 模块列表（susfs4ksu 长啥样）====="
ls -la /data/adb/modules/ 2>&1
echo "--- susfs4ksu 里有什么 ---"
ls -la /data/adb/modules/susfs4ksu/ 2>&1
echo

echo "===== 8. KSU 自家日志（看 su 请求有没有被拒）====="
ls -la /data/adb/ksu/log/ 2>&1
for f in /data/adb/ksu/log/*; do
  [ -f "$f" ] && { echo "--- $f"; tail -40 "$f" 2>&1; }
done
echo

echo "===== 9. kernel 里的 KSU 痕迹 ====="
grep -i kernelsu /proc/version 2>&1
ls /sys/module/ 2>/dev/null | grep -i -E 'kernelsu|ksu'
echo "--- dmesg 里带 ksu 的行 ---"
dmesg 2>/dev/null | grep -i -E 'kernelsu|ksu_|sucompat' | tail -20
echo

echo "===== 10. 容器进程树（看是谁拉起的 proot）====="
ps -A -o PID,PPID,UID,NAME 2>/dev/null | grep -i -E 'proot|rikka|10370' | head -20
echo "--- 所有 10370 的进程 ---"
ps -A -o PID,PPID,UID,ARGS 2>/dev/null | awk '$3==10370' | head -20
} > "$OUT" 2>&1

echo "✅ 写完了："
echo "   $OUT"
echo "   去让你的龙读吧 🐲"
