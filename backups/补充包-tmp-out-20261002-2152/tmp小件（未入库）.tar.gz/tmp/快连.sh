#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快连.sh —— 只给一个 6 位配对码，其余全自动 🐲
==================================================
用法：
    python3 /workspace/tmp/快连.sh 552096           # 一次性
    python3 /workspace/tmp/快连.sh 552096 --watch   # 蹲守 180 秒

扫描用 poll + 非阻塞 connect，2 万端口 ≈ 1 秒内。
"""
import os
import select
import socket
import subprocess
import sys
import time

LO, HI = 30000, 50001
CODE, WATCH = None, False
for a in sys.argv[1:]:
    if a == "--watch":
        WATCH = True
    elif not CODE:
        CODE = a.strip()
if not CODE:
    print("用法: 快连.sh <6位配对码> [--watch]")
    sys.exit(1)

os.environ["HOME"] = "/root"


def adb(*args, timeout=25):
    try:
        r = subprocess.run(["adb", *args], capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip()
    except subprocess.TimeoutExpired:
        return "<超时>"


def scan():
    """poll 非阻塞扫描，返回开放的端口列表"""
    socks, poller = {}, select.poll()
    for p in range(LO, HI):
        s = socket.socket()
        s.setblocking(False)
        try:
            s.connect_ex(("127.0.0.1", p))
        except Exception:
            s.close()
            continue
        socks[s.fileno()] = (s, p)
        poller.register(s, select.POLLOUT | select.POLLERR | select.POLLHUP)
    open_ports, deadline = [], time.time() + 2.0
    while socks and time.time() < deadline:
        for fd, _ev in poller.poll(200):
            s, p = socks.pop(fd, (None, None))
            if s is None:
                continue
            err = s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
            if err == 0:
                open_ports.append(p)
            poller.unregister(s)
            s.close()
    for s, _p in socks.values():
        s.close()
    return sorted(open_ports)


def main():
    print("══ 0. 起 adb server ══")
    print("   " + adb("start-server", timeout=40).splitlines()[-1])

    deadline = time.time() + (180 if WATCH else 1)
    paired = None

    while paired is None:
        t0 = time.time()
        ports = scan()
        print(f"\n══ 扫描 ══ 用时 {time.time()-t0:.2f}s · 开放端口: {ports or '（无）'}")

        if ports:
            print(f"══ 试配对（码={CODE}）══")
            for p in ports:
                out = adb("pair", f"127.0.0.1:{p}", CODE, timeout=20)
                print(f"    → :{p}  {out.splitlines()[0] if out else ''}")
                if "Successfully" in out:
                    paired = p
                    break
            if paired:
                print(f"   ✅ 配对成功！配对端口 = {paired}")
                break

        if time.time() > deadline:
            print("\n   ❌ 没蹲到。配对框关了吧？重开一次再来。")
            sys.exit(1)
        print("   … 没成，1 秒后重扫（配对框保持打开）")
        time.sleep(1)

    print("\n══ 找连接端口 ══")
    time.sleep(1.5)
    ports = scan()
    print(f"   当前开放端口: {ports or '（无）'}")
    connected = False
    for p in ports:
        if p == paired:
            continue
        out = adb("connect", f"127.0.0.1:{p}", timeout=20)
        print(f"    → :{p}  {out.splitlines()[0] if out else ''}")
        if "connected" in out:
            connected = True
            break
    if not connected:
        print("   ⚠️ 兜底：拿配对端口试")
        print("   " + adb("connect", f"127.0.0.1:{paired}", timeout=20))
    print("   " + adb("devices", "-l", timeout=20))

    print("\n══ 验身份 —— 出笼了没？ ══")
    print("   " + adb("shell", "id", timeout=20))
    print("   " + adb("shell", "cat /proc/self/attr/current", timeout=20).replace("\x00", ""))

    print("\n══ 终点：su ══")
    print("   " + adb("shell", "su", "-c", "id; echo SU_OK", timeout=30))


if __name__ == "__main__":
    main()
