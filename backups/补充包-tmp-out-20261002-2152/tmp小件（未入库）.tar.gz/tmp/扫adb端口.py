#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""扫adb端口.py —— 全段扫本地开放端口（poll 非阻塞，约 3-8 秒）"""
import select, socket, sys, time

LO = int(sys.argv[1]) if len(sys.argv) > 1 else 30000
HI = int(sys.argv[2]) if len(sys.argv) > 2 else 50001

socks, poller = {}, select.poll()
for p in range(LO, HI):
    s = socket.socket()
    s.setblocking(False)
    try:
        s.connect_ex(("127.0.0.1", p))
    except Exception:
        s.close()
        continue
    socks[s.fileno()] = (s, p)
    poller.register(s, select.POLLOUT | select.POLLERR | select.POLLHUP)

opened, deadline = [], time.time() + 4.0
while socks and time.time() < deadline:
    for fd, _ in poller.poll(200):
        s, p = socks.pop(fd, (None, None))
        if s is None:
            continue
        if s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) == 0:
            opened.append(p)
        poller.unregister(s)
        s.close()
for s, _ in socks.values():
    s.close()

print(" ".join(str(p) for p in sorted(opened)))
