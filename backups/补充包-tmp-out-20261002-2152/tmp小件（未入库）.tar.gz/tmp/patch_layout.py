import io, sys

def patch(path, pairs):
    s = open(path, encoding="utf-8").read()
    for i, (old, new) in enumerate(pairs, 1):
        n = s.count(old)
        assert n == 1, "%s 第%d处匹配 %d 次（应为 1）:\n%s" % (path, i, n, old[:120])
        s = s.replace(old, new)
    open(path, "w", encoding="utf-8").write(s)
    print("  ✓ %s：%d 处" % (path, len(pairs)))

# ---------------- page.tsx ----------------
P = "app/page.tsx"
patch(P, [
# 1) 窄屏 state
("""  const [isMobile, setIsMobile] = useState(false);""",
 """  const [isMobile, setIsMobile] = useState(false);
  /* ★ 窄屏（手机 / 窄窗口）——只改「面板怎么摆」，**不动功能**。
     原来的毛病：导轨 52 + 左面板 320 + 右检查器 280~480，加起来把手机屏吃光了。
     现在窄屏时左右面板改成【浮层】，画布拿回整宽；桌面一切照旧。 */
  const [narrow, setNarrow] = useState(false);
  const narrowRef = useRef(false);
  narrowRef.current = narrow;
  const [vw, setVw] = useState(0);"""),

# 2) 窄屏探测 effect + 首次收起右侧
("""      ensureFrameRef.current();
      queueMicrotask(() => {
        fitRef.current();
        setViewReady(true);
      });
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);""",
 """      ensureFrameRef.current();
      queueMicrotask(() => {
        fitRef.current();
        setViewReady(true);
      });
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  /* ★ 窄屏探测：只决定「面板浮层化」，跟上面那个手机端检测是两码事 */
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 720px)");
    const apply = () => {
      const n = mq.matches;
      setNarrow(n);
      narrowRef.current = n;
      setVw(window.innerWidth);
    };
    apply();
    mq.addEventListener("change", apply);
    window.addEventListener("resize", apply);
    return () => {
      mq.removeEventListener("change", apply);
      window.removeEventListener("resize", apply);
    };
  }, []);

  /* 窄屏首次进来：右检查器先收起来，画布占满整宽（要用再点右上角那个按钮） */
  const narrowInitRef = useRef(false);
  useEffect(() => {
    if (narrow && !narrowInitRef.current) {
      narrowInitRef.current = true;
      setRightOpen(false);
    }
  }, [narrow]);"""),

# 3) fit 的紧凑内边距
("""    const mobile = mobileRef.current;
    const pad = mobile ? 14 : 40;
    const top = mobile ? 96 : 84; // keep the floating toolbar clear of the frame
    const bottom = mobile ? 96 : pad;""",
 """    const mobile = mobileRef.current;
    /* 窄屏也吃「紧凑内边距」（但不走下面那条「缩放贴满屏宽」的手机分支） */
    const tight = mobile || narrowRef.current;
    const pad = tight ? 14 : 40;
    const top = tight ? 96 : 84; // keep the floating toolbar clear of the frame
    const bottom = tight ? 96 : pad;"""),

# 4) 左侧面板：窄屏浮层 + 限宽
("""          <aside style={{ ...panelStyle, width: leftOpen ? leftW : RAIL_W, flexDirection: "row", transition: "width 200ms cubic-bezier(0.2, 0, 0, 1)" }}>""",
 """          <aside
            style={{
              ...panelStyle,
              width: leftOpen ? (narrow && vw ? Math.max(200, Math.min(leftW, vw - 72)) : leftW) : RAIL_W,
              flexDirection: "row",
              transition: "width 200ms cubic-bezier(0.2, 0, 0, 1)",
              ...(narrow
                ? { position: "absolute" as const, left: 0, top: 0, bottom: 0, zIndex: 60, boxShadow: "0 0 24px rgba(0,0,0,0.30)" }
                : null),
            }}
          >"""),

# 5) 右检查器：窄屏浮层 + 限宽
("""          <aside style={{ ...panelStyle, width: rightW }}>""",
 """          <aside
            style={{
              ...panelStyle,
              width: narrow && vw ? Math.max(240, Math.min(rightW, vw - 56)) : rightW,
              ...(narrow
                ? { position: "absolute" as const, right: 0, top: 0, bottom: 0, zIndex: 60, boxShadow: "0 0 24px rgba(0,0,0,0.30)" }
                : null),
            }}
          >"""),

# 6) 打开右面板的按钮：窄屏时避开顶部工具栏
("""            <div
              style={{ position: "absolute", right: 20, top: 20, zIndex: 45 }}
            >""",
 """            <div
              style={{ position: "absolute", right: narrow ? 12 : 20, top: narrow ? 96 : 20, zIndex: 45 }}
            >"""),

# 7) 工具栏：浮层化的右面板不再挤它
("""            rightInset={showRight ? rightW : 0}
            mobile={isMobile}""",
 """            rightInset={showRight && !narrow ? rightW : 0}
            mobile={isMobile}
            narrow={narrow}"""),
])

# ---------------- Toolbar.tsx ----------------
T = "components/Toolbar.tsx"
patch(T, [
("""  mobile?: boolean;""",
 """  mobile?: boolean;
  /** 窄屏：工具栏不铺满居中，改成可换行的紧凑排列（功能一个不少） */
  narrow?: boolean;"""),
("""  rightInset,""",
 """  rightInset,
  narrow,"""),
("""          position: "absolute",
          left: 0,
          right: 0,
          top: 14,
          display: "flex",
          justifyContent: "center",
          gap: 10,
          pointerEvents: "none",
          zIndex: 40,
          flexWrap: "nowrap",
          padding: "0 72px",""",
 """          position: "absolute",
          left: 0,
          right: 0,
          top: 10,
          display: "flex",
          justifyContent: "center",
          gap: narrow ? 6 : 10,
          pointerEvents: "none",
          zIndex: 40,
          flexWrap: narrow ? "wrap" : "nowrap",
          rowGap: 6,
          padding: narrow ? "0 6px" : "0 72px","""),
])

# ---------------- globals.css ----------------
C = "app/globals.css"
patch(C, [
(""".app-root {
  height: 100vh;""",
 """.app-root {
  /* 窄屏时左右面板要相对它做浮层定位 */
  position: relative;
  height: 100vh;"""),
])
print("全部补丁 OK")
