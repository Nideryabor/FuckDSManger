#!/bin/sh
# ============================================================================
#  探真su.sh —— 验一验新给的 su 是不是"真家伙" 🐲
#
#  用法：
#      sh /workspace/tmp/探真su.sh                # 探 PATH 里的 su
#      sh /workspace/tmp/探真su.sh /path/to/su    # 探指定的 su
#
#  ★ 全程只读：只 ls / cat / id，不写、不装、不改任何东西。
# ============================================================================

SU="${1:-su}"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); printf '  \033[32m✅ %s\033[0m\n' "$1"; }
no()   { FAIL=$((FAIL+1)); printf '  \033[31m❌ %s\033[0m\n' "$1"; }
head_() { printf '\n\033[36m══ %s\033[0m\n' "$1"; }

RUN() { timeout 20 "$SU" -c "$1" 2>&1; }

head_ "0. 这个 su 是什么"
ls -la "$SU" 2>/dev/null || no "找不到 $SU"

head_ "1. 提权身份（关键看 CapEff）"
ID_OUT=$(RUN 'id; echo "---"; grep -E "^Cap(Eff|Prm|Bnd)" /proc/self/status')
echo "$ID_OUT" | sed 's/^/     /'
case "$ID_OUT" in
  *CapEff:\	0000000000000000*) no "CapEff 还是 0 —— 纸老虎 root（跟现在一样）" ;;
  *CapEff:*)                     ok "CapEff 非零 —— 真能力到手 🎉" ;;
  *)                             no "读不到 CapEff" ;;
esac

head_ "2. 能不能看见别的进程（破 hidepid）"
N=$(RUN 'ls /proc/ | grep -cE "^[0-9]+$"')
echo "     可见进程数：$N"
if [ "$N" -gt 50 ] 2>/dev/null; then ok "hidepid 破了（>50 进程）"
else no "还是只有自己的进程（hidepid 没破）"; fi

head_ "3. 能不能从 /proc/1/root 踩到安卓真根"
R1=$(RUN 'ls /proc/1/root/ 2>&1 | head -5')
echo "$R1" | sed 's/^/     /'
case "$R1" in
  *No\ such*|*Permission*|*"not found"*) no "/proc/1/root 进不去" ;;
  *) ok "摸到安卓根了 ✅✅✅" ;;
esac

head_ "4. 三个关键抓手（只读）"
for probe in \
  "ro.product.model=$(RUN 'getprop ro.product.model')" \
  "宿主数据目录=$(RUN 'ls -d /proc/1/root/data/data/com.deepseek.chat.a 2>&1')" \
  "logcat=$(RUN 'ls -la /proc/1/root/system/bin/logcat 2>&1')" \
  "pm=$(RUN 'ls -la /proc/1/root/system/bin/pm 2>&1')" \
  "我们的包=$(RUN 'ls -d /proc/1/root/data/data/com.little_femaleboy.cannot_show.the_big_won_whale 2>&1')" \
; do
  k="${probe%%=*}"; v="${probe#*=}"
  case "$v" in
    *No\ such*|*Permission*|*"not found"*|"") no "$k → $v" ;;
    *) ok "$k → $v" ;;
  esac
done

head_ "5. 最后试一枪：模拟 logcat 取一次（只读，不落盘）"
LC=$(RUN 'logcat -d -t 3 2>&1 || /proc/1/root/system/bin/logcat -d -t 3 2>&1')
case "$LC" in
  *"not found"*|*Permission*) no "logcat 还拿不到" ;;
  *) echo "$LC" | head -3 | sed 's/^/     /'; ok "logcat 通了" ;;
esac

printf '\n\033[36m══ 结论 ══\033[0m\n'
printf '   通过 %d 项 / 失败 %d 项\n' "$PASS" "$FAIL"
if [ "$FAIL" -eq 0 ]; then
  printf '   \033[32m🚀 全通 —— 隧道打穿了，我自己就能抓日志+装包\033[0m\n'
elif [ "$PASS" -ge 2 ]; then
  printf '   \033[33m⚠️ 半通 —— 再想想绕法（贴给我看）\033[0m\n'
else
  printf '   \033[31m😿 没通 —— 还是得走跑腿脚本那条路\033[0m\n'
fi
