#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""连设备上由「命令」页起的 backpipe shell，发一串命令、收回显。
用法：python3 tmp/sh_client.py [端口] ['命令1; 命令2; ...']
"""
import socket
import sys
import time

port = int(sys.argv[1]) if len(sys.argv) > 1 else 9999
cmds = sys.argv[2] if len(sys.argv) > 2 else "id; getprop ro.build.version.release; echo ---OK---"

try:
    s = socket.create_connection(("127.0.0.1", port), timeout=6)
except Exception as e:
    print("✗ 连不上 127.0.0.1:%d -> %s" % (port, e))
    sys.exit(1)

s.settimeout(4)
try:
    s.sendall((cmds + "\n").encode())
except Exception as e:
    print("✗ 发不出去:", e)
    sys.exit(1)

buf = b""
deadline = time.time() + 8
while time.time() < deadline:
    try:
        d = s.recv(8192)
    except socket.timeout:
        break
    except Exception as e:
        print("(recv err: %s)" % e)
        break
    if not d:
        break
    buf += d

print("=== 回显 %d 字节 ===" % len(buf))
print(buf.decode("utf-8", errors="replace"))
s.close()
