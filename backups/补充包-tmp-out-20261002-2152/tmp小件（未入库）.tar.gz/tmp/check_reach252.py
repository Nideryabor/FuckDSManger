#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""2.5.2 老锚点 → uia.v 一跳可达性（对照用）"""
import re

H252 = "/workspace/tmp/h252"

def methods(file):
    out, cur = {}, None
    with open(file, encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = re.match(r"^\.method.*?\s([a-zA-Z0-9_$<>]+)\(([^)]*)\)(\S+)\s*$", line.strip())
            if m:
                cur = m.group(1); out[cur] = []; continue
            if line.strip() == ".end method":
                cur = None; continue
            if cur is not None:
                out[cur].append(line.strip())
    return out

anchors = {
    "uk8": ["a", "b", "c"],
    "zc": ["c", "d", "h", "l"],
    "i52": ["e"],
    "yb5": ["c", "d"],
    "a18": ["q"],
    "zl9": ["H", "Z"],
}

for cls, meths in anchors.items():
    try:
        ms = methods("%s/%s.smali" % (H252, cls))
    except FileNotFoundError:
        print("### %s.smali 不存在" % cls); continue
    dset = set(n for n, b in ms.items() if any("uia;->v(" in l for l in b))
    print("### %s：含 uia.v 的方法 = %s" % (cls, sorted(dset) or "无"))
    for m in meths:
        body = ms.get(m, [])
        called = set(re.findall(r"%s->([a-zA-Z0-9_$]+)\(" % cls, "\n".join(body)))
        direct = any("uia;->v(" in l for l in body)
        via = sorted(called & dset)
        if direct:
            print("  %s.%s → 直接 ✅" % (cls, m))
        elif via:
            print("  %s.%s → 一跳 ✅ 经 %s" % (cls, m, via))
        else:
            print("  %s.%s → ⚠ 未见到（可能跨类）" % (cls, m))
    print()
