#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对照：老锚点(2.5.2)是否直接画底 vs 新锚点(2.6.1)是否直接画底"""
import re, sys

def methods(file):
    out = {}
    cur = None
    with open(file, encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = re.match(r"^\.method.*?\s([a-zA-Z0-9_$<>]+)\(([^)]*)\)(\S+)\s*$", line.strip())
            if m:
                cur = m.group(1)
                out[cur] = []
                continue
            if line.strip() == ".end method":
                cur = None
                continue
            if cur is not None and ("invoke" in line):
                out[cur].append(line.strip())
    return out

def direct_call(ms, meth, needle):
    body = "\n".join(ms.get(meth, []))
    return needle in body

print("=== 2.5.2：老锚点是否直接调 Luia;->v( ===")
H252 = "/workspace/tmp/h252"
old = [("uk8","a"),("uk8","b"),("uk8","c"),("zc","c"),("zc","d"),("zc","h"),("zc","l"),
       ("i52","e"),("yb5","c"),("yb5","d"),("a18","q"),("zl9","H"),("zl9","Z")]
for cls, meth in old:
    ms = methods("%s/%s.smali" % (H252, cls))
    print("%s.%s : %s" % (cls, meth, "直接✅" if direct_call(ms, meth, "Luia;->v(") else "间接/无"))

print()
print("=== 2.6.1：新锚点是否直接调 Lqk7;->D( ===")
H261 = "/workspace/tmp/h261"
new = [("xta","a"),("xta","b"),("xta","c"),("l10","a"),("l10","b"),("l10","c"),("l10","d"),
       ("v91","c"),("hs7","c"),("hs7","d"),("l10","h"),("k53","f"),("k53","o")]
for cls, meth in new:
    ms = methods("%s/%s.smali" % (H261, cls))
    has_d = direct_call(ms, meth, "Lqk7;->D(")
    has_other = [k for k in (";->C(",";->e(",";->M(",";->N(") if direct_call(ms, meth, "Lqk7"+k)]
    print("%s.%s : D=%s  其它qk7调用=%s" % (cls, meth, "✅" if has_d else "✗", has_other or "无"))
