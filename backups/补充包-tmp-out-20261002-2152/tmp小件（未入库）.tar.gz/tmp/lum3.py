from PIL import Image
import sys

def hx(c): return "#%02X%02X%02X" % c

TARGETS = {
  "#0F0F0F (日志 bg#1~#4 页面底色)": (0x0F,0x0F,0x0F),
  "#292929 (日志 bg#5 内容区)":      (0x29,0x29,0x29),
  "#E5E5E5 (日志 bg#8)":             (0xE5,0xE5,0xE5),
  "#FFFFFF (浅色页面底色)":           (0xFF,0xFF,0xFF),
}

def analyze(path, tol=6):
    im = Image.open(path).convert('RGB')
    W, H = im.size
    sm = im.resize((240, 528), Image.LANCZOS); p = sm.load(); w,h = 240,528
    print("="*72); print(f"FILE: {path}  size={W}x{H}  tol=±{tol}")
    # 每个目标色的占比 + 3x3 分布
    for name,(tr,tg,tb) in TARGETS.items():
        tot=0; grid=[[0]*3 for _ in range(3)]
        for y in range(h):
            for x in range(w):
                r,g,b = p[x,y]
                if abs(r-tr)<=tol and abs(g-tg)<=tol and abs(b-tb)<=tol:
                    tot+=1; grid[min(y*3//h,2)][min(x*3//w,2)]+=1
        pct = 100.0*tot/(w*h)
        if pct < 0.05:
            print(f"  {name:34s} {pct:5.2f}%   (基本没有)")
            continue
        print(f"  {name:34s} {pct:5.2f}%   分布(行×列):")
        for row in grid:
            print("      " + "  ".join(f"{100.0*c/max(tot,1):5.1f}%" for c in row))
    # 3x3 每格的主色
    print("--- 3x3 网格各方块主色 ---")
    q = im.resize((w,h), Image.LANCZOS)
    for gy in range(3):
        line=[]
        for gx in range(3):
            cell = q.crop((gx*w//3, gy*h//3, (gx+1)*w//3, (gy+1)*h//3))
            c = cell.quantize(colors=4).convert('RGB')
            cnt={}
            cp=c.load()
            for y in range(c.size[1]):
                for x in range(c.size[0]):
                    cnt[cp[x,y]]=cnt.get(cp[x,y],0)+1
            top=sorted(cnt.items(), key=lambda kv:-kv[1])[0][0]
            line.append(f"[{gy},{gx}] {hx(top)}")
        print("   " + " | ".join(line))
for p in sys.argv[1:]:
    analyze(p)
