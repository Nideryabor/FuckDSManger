#!/bin/sh
# dev.sh —— 设备命令（adbd 5555）。⚠️ 所有调用都套硬超时，卡住即断（主人要求）。
#   用法: sh tmp/dev.sh '<cmd>'  |  --su '<cmd>'  |  --install <apk>
export HOME=/root
timeout 15 adb start-server >/dev/null 2>&1
timeout 10 adb connect 127.0.0.1:5555 >/dev/null 2>&1
D="-s 127.0.0.1:5555"
case "$1" in
    --install) shift; exec timeout 180 adb $D install -r --user 0 "$@" ;;
    --su)      shift; exec timeout 25 adb $D shell "su -c '$*'" ;;
    *)         exec timeout 25 adb $D shell "$*" ;;
esac
