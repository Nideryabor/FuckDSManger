#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 /workspace 现状（15064 个受管文件）同步进逃生包克隆树 tmp/restore-clone。
   - 拷：全部清单路径（内容 + 权限位；符号链接按链接拷）
   - 删：清单外、克隆里仍有的旧文件（restore-del.z，4 个 stub）
"""
import os, shutil, sys

WS = '/workspace'
CL = '/workspace/tmp/restore-clone'

def load_z(p):
    with open(p, 'rb') as f:
        return [x for x in f.read().split(b'\0') if x]

cur = load_z(WS + '/tmp/restore-cur.z')
dele = load_z(WS + '/tmp/restore-del.z')

copied = skipped = errs = 0
for b in cur:
    rel = b.decode('utf-8', 'surrogateescape')
    src = os.path.join(WS, rel)
    dst = os.path.join(CL, rel)
    try:
        if os.path.islink(src):
            if os.path.lexists(dst):
                os.remove(dst)
            os.symlink(os.readlink(src), dst)
            copied += 1
            continue
        if not os.path.isfile(src):
            print('SKIP(不存在):', rel); skipped += 1; continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        os.chmod(dst, os.stat(src).st_mode & 0o7777)
        copied += 1
    except Exception as e:
        print('ERR:', rel, e); errs += 1

removed = 0
for b in dele:
    rel = b.decode('utf-8', 'surrogateescape')
    dst = os.path.join(CL, rel)
    try:
        if os.path.lexists(dst):
            os.remove(dst); removed += 1
    except Exception as e:
        print('RM-ERR:', rel, e)

print('copied=%d skipped=%d errs=%d removed=%d' % (copied, skipped, errs, removed))
