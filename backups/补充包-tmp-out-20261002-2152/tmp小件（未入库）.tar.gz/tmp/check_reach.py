#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""锚点 → qk7.D 一跳可达性核验：锚点体里调用过的同类方法，是否含 qk7.D"""
import re

H261 = "/workspace/tmp/h261"

def methods(file):
    out, cur = {}, None
    with open(file, encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = re.match(r"^\.method.*?\s([a-zA-Z0-9_$<>]+)\(([^)]*)\)(\S+)\s*$", line.strip())
            if m:
                cur = m.group(1); out[cur] = []; continue
            if line.strip() == ".end method":
                cur = None; continue
            if cur is not None:
                out[cur].append(line.strip())
    return out

anchors = {
    "xta": ["a", "b", "c"],
    "l10": ["a", "b", "c", "d", "h"],
    "v91": ["c"],
    "hs7": ["c", "d"],
    "k53": ["f", "o"],
}

for cls, meths in anchors.items():
    ms = methods("%s/%s.smali" % (H261, cls))
    dset = set(n for n, b in ms.items() if any("qk7;->D(" in l for l in b))
    print("### %s：含 qk7.D 的方法 = %s" % (cls, sorted(dset) or "无"))
    for m in meths:
        body = ms.get(m, [])
        called = set(re.findall(r"%s->([a-zA-Z0-9_$]+)\(" % cls, "\n".join(body)))
        direct = any("qk7;->D(" in l for l in body)
        via = sorted(called & dset)
        if direct:
            print("  %s.%s → 直接 ✅" % (cls, m))
        elif via:
            print("  %s.%s → 一跳 ✅ 经 %s" % (cls, m, via))
        else:
            # 再看二跳：called 里哪些方法又调了含D的方法
            two = set()
            for c in called:
                cb = ms.get(c, [])
                ccalled = set(re.findall(r"%s->([a-zA-Z0-9_$]+)\(" % cls, "\n".join(cb)))
                if any("qk7;->D(" in l for l in cb):
                    two.add(c)
                two |= (ccalled & dset)
            print("  %s.%s → %s" % (cls, m, ("二跳 ✅ 经 %s" % sorted(two)) if two else "⚠ 未见到（可能跨类）"))
    print()
