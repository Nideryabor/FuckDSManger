#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对扫到的本地端口做指纹：banner / HTTP / adb(CNXN) / unix abstract"""
import socket, struct, sys, zlib

PORTS = [int(x) for x in sys.argv[1:]] or [3001, 10152, 12121, 33068, 33465, 42398, 45743, 46888, 59286, 60653]


def adb_cnxn():
    payload = b"host::\x00"
    arg0, arg1 = 0x01000001, 0x00100000
    return (b"CNXN" + struct.pack("<III", arg0, arg1, len(payload))
            + struct.pack("<I", zlib.crc32(payload) & 0xFFFFFFFF)
            + struct.pack("<I", arg0 ^ 0xFFFFFFFF) + payload)


def probe(p):
    print("=== port %d ===" % p)
    # ① 空连 + banner
    try:
        s = socket.create_connection(("127.0.0.1", p), timeout=2)
        s.settimeout(1.5)
        try:
            d = s.recv(200)
            print("   banner:", repr(d[:120]))
        except Exception as e:
            print("   (no banner):", type(e).__name__)
        # ② HTTP
        try:
            s.sendall(b"GET / HTTP/1.0\r\nHost: x\r\n\r\n")
            d = s.recv(200)
            print("   http:", repr(d[:120]))
        except Exception as e:
            print("   http err:", type(e).__name__)
        s.close()
    except Exception as e:
        print("   connect fail:", e)
        return
    # ③ adb CNXN
    try:
        s = socket.create_connection(("127.0.0.1", p), timeout=2)
        s.settimeout(2.0)
        s.sendall(adb_cnxn())
        d = s.recv(200)
        print("   adb:", repr(d[:120]))
        s.close()
    except Exception as e:
        print("   adb err:", type(e).__name__, str(e)[:60])


for p in PORTS:
    probe(p)

print("=== unix abstract sockets ===")
for name in [b"\x00shizuku_rish", b"\x00shizuku", b"\x00rish", b"\x00shizuku_server",
             b"\x00shizuku_rish_shell", b"\x00adb"]:
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1.5)
        s.connect(name)
        print("   ✅ connectable:", name)
        s.close()
    except Exception as e:
        print("   ✗", name, "->", type(e).__name__, str(e)[:60])
