#!/bin/sh
# ============================================================================
#  测sucompat.sh —— 专测 KernelSU-Next 的「SU 兼容模式」有没有生效 🐲
#
#  原理：su_compat 是【内核】在 execve 一个名叫 "su" 的文件时直接改 creds，
#        **完全不看 setuid 位** ⇒ NoNewPrivs=1 拦不住它。
#        所以只要「RikkaHub 在授权名单 + su_compat 开着」，
#        容器里这个假 su 会在一瞬间变成真 root。
#
#  判定只认一个东西：/proc/self/status 里的 Uid（proot 伪造不了这个文件）
#
#  ★ 全程只读。
# ============================================================================

printf '\033[36m══ 内核怎么看我（不信 proot 的嘴）══\033[0m\n'
before=$(grep '^Uid:' /proc/self/status)
printf '  执行前 Uid: %s\n' "$(echo "$before" | cut -f2-)"

printf '\n\033[36m══ 造一个名叫 su 的可执行文件 ══\033[0m\n'
mkdir -p /tmp/sucompat
# 必须有名字叫 su 的文件；用真的 su 二进制（内核只看名字，不看内容）
if [ -x /usr/bin/su ]; then
  cp -f /usr/bin/su /tmp/sucompat/su 2>/dev/null && printf '  已放置：/tmp/sucompat/su（%s 字节）\n' "$(stat -c%s /tmp/sucompat/su)"
else
  printf '  ❌ 找不到 /usr/bin/su\n'; exit 1
fi

printf '\n\033[36m══ 执行它，看内核给不给脸 ══\033[0m\n'
out=$(timeout 20 /tmp/sucompat/su -c 'grep "^Uid:" /proc/self/status' 2>&1)
printf '  执行后 Uid: %s\n' "$(echo "$out" | sed 's/^Uid:[[:space:]]*//')"

printf '\n\033[36m══ 顺带看 SELinux 域有没有被换成 ksu ══\033[0m\n'
ctx=$(timeout 20 /tmp/sucompat/su -c 'cat /proc/self/attr/current' 2>&1 | tr -d '\0')
printf '  域: %s\n' "$ctx"

printf '\n\033[36m══ 结论 ══\033[0m\n'
if echo "$out" | grep -qE '^Uid:[[:space:]]*0[[:space:]]'; then
  printf '  \033[32m🚀 真 root 到手！su_compat 生效了\033[0m\n'
else
  printf '  \033[31m😿 还是 10370 —— su_compat 没生效\033[0m\n'
  printf '     两条可能：\n'
  printf '      ① KernelSU-Next 里没授权 RikkaHub（uid 10370）\n'
  printf '      ② 授权了，但「SU 兼容模式 / su_compat」没开\n'
  printf '     开关落在：/data/adb/ksu/.feature_config\n'
fi
