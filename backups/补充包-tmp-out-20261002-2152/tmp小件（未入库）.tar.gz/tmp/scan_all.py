#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全端口扫描（分批，避免 fd 上限）—— 找 Shizuku rish / adb / 任何监听在 127.0.0.1 的服务"""
import socket, select, sys, time


def scan(lo, hi, batch=1200, wait=0.45):
    opened = []
    for start in range(lo, hi, batch):
        end = min(start + batch, hi)
        socks, poller = {}, select.poll()
        for p in range(start, end):
            s = socket.socket()
            s.setblocking(False)
            try:
                s.connect_ex(("127.0.0.1", p))
            except Exception:
                s.close()
                continue
            socks[s.fileno()] = (s, p)
            poller.register(s, select.POLLOUT | select.POLLERR | select.POLLHUP)
        deadline = time.time() + wait
        while socks and time.time() < deadline:
            for fd, _ in poller.poll(80):
                s, p = socks.pop(fd, (None, None))
                if s is None:
                    continue
                if s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) == 0:
                    opened.append(p)
                poller.unregister(s)
                s.close()
        for s, _ in socks.values():
            s.close()
    return sorted(opened)


if __name__ == "__main__":
    lo = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    hi = int(sys.argv[2]) if len(sys.argv) > 2 else 65536
    print(" ".join(str(p) for p in scan(lo, hi)))
